from __future__ import annotations

import asyncio
import ipaddress
import secrets
from contextlib import asynccontextmanager
from pathlib import Path
from time import perf_counter
from typing import Annotated, Any, Literal

from fastapi import FastAPI, Header, HTTPException, Query, Request, Response
from fastapi import Path as ApiPath
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field

from bidpilot import __version__
from bidpilot.config import Settings, get_settings
from bidpilot.control import ControlPlane
from bidpilot.delivery import DeliveryError
from bidpilot.intent_snapshot import IntentSnapshotError
from bidpilot.models import (
    BuyerRadarResult,
    BuyerSubscriptionCreate,
    CompanyProfile,
    CompanyProfileUpdate,
    EvidenceAnswer,
    EvidenceQuestionRequest,
    FeedbackUpdate,
    HealthResponse,
    IntentComparison,
    Opportunity,
    OpportunityAssessmentSet,
    OpportunityCreate,
    OpportunityStage,
    OpportunityUpdate,
    RunResult,
    Subscription,
    SubscriptionCreate,
    SubscriptionUpdate,
    TenderFeedback,
    TenderQuerySpec,
    TenderRecord,
)
from bidpilot.network_access import client_in_trusted_networks
from bidpilot.runtime_config import (
    ConfigEditTokenManager,
    ConnectionTestResult,
    RuntimeConfigConflict,
    RuntimeConfigError,
    RuntimeConfigUpdate,
    RuntimeConfigView,
)
from bidpilot.scheduler import SubscriptionWorker
from bidpilot.service import (
    BidPilotService,
    DeliveryOutboxStateError,
    RunEvidenceNotReadyError,
    SubscriptionBusyError,
)
from bidpilot.source_auth import (
    SourceAuthError,
    SourceAuthSessionView,
    SourceAuthTestResult,
    SourceAuthView,
)
from bidpilot.sources.base import SourceAdapter


class QueryRequest(BaseModel):
    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "query": "最近1个月深圳充电桩招标信息",
                    "delivery_channel": "local",
                    "delivery_targets": ["local", "email"],
                }
            ]
        }
    )

    query: str = Field(description="中文招投标需求，长度 2～500 字", min_length=2, max_length=500)
    delivery_channel: str = Field(
        default="local",
        description="本轮投递通道；解析接口不会执行该字段",
    )
    delivery_targets: list[str] | None = Field(
        default=None,
        max_length=10,
        description="本轮可同时使用的交付目标；省略时兼容 delivery_channel",
    )
    intent_snapshot: str | None = Field(
        default=None,
        max_length=100_000,
        description=(
            "解析预览返回的限时签名快照；执行时验证原问题、签名和时效，避免再次调用模型后字段漂移"
        ),
        repr=False,
    )


class ResumeRequest(BaseModel):
    run_immediately: bool = Field(
        default=False,
        description="恢复后是否把下一次时间设为立即到期",
    )


class ConfigEditTokenResponse(BaseModel):
    edit_token: str = Field(description="用于同源配置和来源授权写入的短期防跨站令牌")
    expires_in: int = Field(description="令牌剩余有效秒数")


class DeleteResultResponse(BaseModel):
    deleted: Literal[True] = Field(
        default=True,
        description="目标资源已完成删除；不存在或已删除时接口返回 404 而不是 false",
    )


class DeletedCountResponse(BaseModel):
    deleted_count: int = Field(
        ge=0,
        description="本次批量操作实际删除的本地记录数量",
    )


class WorkerStatusResponse(BaseModel):
    id: str = Field(description="worker 唯一实例 ID，用于识别租约所有者")
    kind: str = Field(description="worker 类型，例如 embedded 或 standalone")
    started_at: str = Field(description="worker 启动时间，ISO 8601")
    heartbeat_at: str = Field(description="最近一次持久心跳时间，ISO 8601")
    pid: int = Field(description="worker 所在进程 ID")
    hostname: str = Field(description="worker 所在主机名")
    online: bool = Field(description="最近心跳是否仍在配置的有效窗口内")


class DeliveryChannelStatusResponse(BaseModel):
    id: str = Field(description="API 和 delivery_targets 使用的稳定通道 ID")
    name: str = Field(description="网页展示的通道名称")
    configured: bool = Field(description="当前必要字段是否已完成配置")
    push_capable: bool = Field(description="是否会主动向外部平台发送提醒")
    supports_text: bool = Field(description="是否支持文本或消息回执")
    supports_file: bool = Field(description="是否支持直接交付 Word 文件")
    supports_link: bool = Field(description="是否支持发送报告下载链接")
    configuration_group: str = Field(description="网页配置卡分组，用于准确跳转配置")
    delivery_semantics: Literal["local_persistence", "at_least_once"] = Field(
        description="本地持久化或外部至少一次投递语义；外部平台不虚构端到端恰好一次"
    )
    message: str = Field(description="能力边界、附件方式和下一步操作的中文说明")


class IntentEngineStatusResponse(BaseModel):
    requests: int = Field(description="本进程实际发出的意图模型请求数")
    applied: int = Field(description="通过本地校验并修正字段的次数")
    confirmed: int = Field(description="模型复核后确认规则结果的次数")
    fallbacks: int = Field(description="提议被拒绝、无效或不可用后安全回退次数")
    invalid_responses: int = Field(description="不符合严格 JSON 契约的模型响应数")
    mode: Literal["off", "auto", "always"] = Field(description="当前意图模型调用策略")
    confidence_threshold: float = Field(description="自动触发模型复核的字段置信阈值")


class SystemStatusResponse(BaseModel):
    worker_online: bool = Field(description="是否至少有一个长期任务 worker 在线")
    workers: list[WorkerStatusResponse] = Field(description="全部已登记 worker 及其心跳状态")
    subscription_count: int = Field(description="持久订阅总数")
    enabled_subscription_count: int = Field(description="当前启用的订阅数")
    running_subscription_count: int = Field(description="当前持有有效运行租约的订阅数")
    due_count: int = Field(description="已经到期、等待 worker 领取的订阅数")
    delivery_channels: list[DeliveryChannelStatusResponse] = Field(
        description="可选交付目标、就绪状态和文本/文件/链接能力矩阵"
    )
    intent_engine: IntentEngineStatusResponse = Field(description="混合意图引擎进程内指标")
    timezone: str = Field(description="计划计算使用的 IANA 时区")


OPENAPI_TAGS = [
    {"name": "系统", "description": "健康检查、运行状态与数据源诊断。"},
    {"name": "意图解析", "description": "把中文自然语言编译为可执行的结构化检索条件。"},
    {"name": "情报任务", "description": "执行多源检索、证据聚合、报告生成与投递。"},
    {"name": "报告", "description": "列出和下载系统真实生成的 Word 报告。"},
    {"name": "长期订阅", "description": "创建、编辑、暂停、恢复和审计持久化订阅。"},
    {
        "name": "买方雷达",
        "description": "只聚合本机已抓取标讯，查看采购单位活动、公告生命周期、主题和证据入口，并创建精确买方监控订阅。",
    },
    {"name": "机会工作台", "description": "把已抓取标讯转为项目级跟进机会并查看生命周期。"},
    {"name": "决策智能", "description": "管理企业画像、本轮证据快照和用户反馈学习数据。"},
    {"name": "配置中心", "description": "安全管理模型与推送通道，并执行真实连通性测试。"},
    {"name": "来源授权", "description": "由用户本人完成可见浏览器登录，并管理加密的来源会话。"},
]


def _api_docs(
    *,
    tag: str,
    summary: str,
    purpose: str,
    parameters: str,
    returns: str,
    side_effects: str,
    errors: str,
    example: str,
    responses: dict[int, str] | None = None,
) -> dict[str, Any]:
    response_docs = {
        code: {"description": description} for code, description in (responses or {}).items()
    }
    return {
        "tags": [tag],
        "summary": summary,
        "description": (
            f"### 用途\n{purpose}\n\n"
            f"### 参数与请求体\n{parameters}\n\n"
            f"### 返回值\n{returns}\n\n"
            f"### 副作用\n{side_effects}\n\n"
            f"### 常见错误\n{errors}\n\n"
            f"### 示例\n```text\n{example}\n```"
        ),
        "response_description": returns,
        "responses": response_docs,
    }


def _key_error_detail(error: KeyError) -> str:
    return str(error.args[0]) if error.args else str(error)


def create_app(
    settings: Settings | None = None,
    sources: list[SourceAdapter] | None = None,
) -> FastAPI:
    settings = settings or get_settings()
    service = BidPilotService(settings, sources=sources)
    config_tokens = ConfigEditTokenManager()
    control_plane = ControlPlane(settings)

    def is_loopback_request(request: Request) -> bool:
        client_host = request.client.host if request.client else ""
        try:
            return ipaddress.ip_address(client_host).is_loopback
        except ValueError:
            return client_host == "testclient"

    def require_config_token(
        x_bidpilot_config_token: Annotated[
            str | None,
            Header(alias="X-BidPilot-Config-Token"),
        ] = None,
    ) -> None:
        if not config_tokens.validate(x_bidpilot_config_token):
            raise HTTPException(status_code=403, detail="配置编辑令牌缺失、无效或已过期")

    def require_management_config_token(token: str | None) -> None:
        require_config_token(token)

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        worker = None
        if settings.embedded_worker:
            worker = SubscriptionWorker(service, kind="embedded")
            service.worker = worker
            worker.start()
        try:
            yield
        finally:
            await service.source_auth.close_all()
            if worker:
                await worker.stop()

    app = FastAPI(
        title="标擎 BidPilot API",
        version=__version__,
        description=(
            "标擎是证据优先的招投标情报 Agent。所有业务接口都在下方说明用途、参数、"
            "返回值、副作用、错误码和调用示例；带有真实抓取、外部推送、配置写入或删除"
            "副作用的接口会醒目标注。默认服务仅监听本机。"
        ),
        openapi_tags=OPENAPI_TAGS,
        lifespan=lifespan,
    )

    @app.middleware("http")
    async def guard_lan_mutations(request: Request, call_next):
        if request.method.upper() in {"POST", "PUT", "PATCH", "DELETE"} and not is_loopback_request(
            request
        ):
            control_shutdown = (
                request.url.path == "/api/v1/system/shutdown"
                and control_plane.verify(request.headers.get("X-BidPilot-Control-Token"))
            )
            if control_shutdown:
                return await call_next(request)
            supplied = request.headers.get("X-BidPilot-Admin-Token", "")
            effective_mode = service.runtime_config.effective_restart_value("network_access_mode")
            effective_policy = service.runtime_config.effective_restart_value("lan_access_policy")
            effective_token = str(service.runtime_config.effective_restart_value("lan_admin_token"))
            effective_networks = str(
                service.runtime_config.effective_restart_value("lan_trusted_networks")
            )
            trusted_client = effective_policy == "trusted_lan" and client_in_trusted_networks(
                request.client.host if request.client else "",
                effective_networks,
            )
            valid_admin = (
                effective_policy == "admin_token"
                and bool(effective_token)
                and secrets.compare_digest(supplied, effective_token)
            )
            allowed = effective_mode == "lan" and (trusted_client or valid_admin)
            if not allowed:
                if effective_mode != "lan":
                    detail = "当前服务没有开放局域网写操作；请在服务主机配置并重启"
                elif effective_policy == "trusted_lan":
                    detail = "当前设备地址不在可信局域网范围；请在服务主机检查可信网段配置"
                else:
                    detail = "局域网写操作需要有效的管理员令牌；请输入服务主机配置的令牌"
                return JSONResponse(
                    status_code=403,
                    content={"detail": detail},
                )
        return await call_next(request)

    app.state.service = service
    app.state.config_tokens = config_tokens
    app.state.control_plane = control_plane
    static_dir = Path(__file__).parent / "static"
    app.mount("/static", StaticFiles(directory=static_dir), name="static")

    @app.get("/", include_in_schema=False)
    async def index():
        return FileResponse(static_dir / "index.html")

    @app.get(
        "/health",
        response_model=HealthResponse,
        **_api_docs(
            tag="系统",
            summary="检查服务健康状态",
            purpose="供浏览器、容器编排和运维探针确认 API 进程可响应，并查看当前版本与存储位置。",
            parameters="无请求体、无查询参数。",
            returns="HTTP 200；返回状态、版本、SQLite 路径和报告目录。",
            side_effects="无。不会访问外部网站，也不会写入数据库。",
            errors="服务未启动或进程崩溃时无法建立连接；该接口本身不产生业务错误码。",
            example="GET /health",
        ),
    )
    async def health():
        return HealthResponse(
            status="ok",
            version=__version__,
            database=str(settings.database_path),
            report_dir=str(settings.report_dir),
        )

    @app.post(
        "/api/v1/intent/parse",
        response_model=TenderQuerySpec,
        **_api_docs(
            tag="意图解析",
            summary="解析中文招投标意图",
            purpose="先用确定性规则拆解中文需求；仅在低置信、缺失或冲突时调用已配置 LLM 提议修复，再由本地地域、日期、计划和枚举校验器逐字段决定是否合并。",
            parameters="JSON 请求体：`query` 为 2～500 字自然语言；`delivery_channel` 在本接口中仅兼容接收，不改变解析结果。",
            returns="HTTP 200；返回完整 TenderQuerySpec、字段置信度、警告、不含密钥和模型原文的 resolution 解释轨迹，以及绑定原问题、服务端签名且 15 分钟有效的 confirmation_snapshot。",
            side_effects="不抓取网站、不生成报告、不创建订阅。若模式为 auto/always 且满足触发条件，会把原问题和规则基线发送到用户配置的模型服务；失败自动回退。",
            errors="422：问题太短、规则层日期或计划数值非法，或请求体格式不正确。模型错误不会让本接口失败。",
            example='POST /api/v1/intent/parse\n{"query":"最近1个月深圳充电桩招标信息"}',
            responses={422: "自然语言为空、过短或包含无效的日期/计划值。"},
        ),
    )
    async def parse_intent(request: QueryRequest):
        try:
            return await service.parse_intent(request.query)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    @app.post(
        "/api/v1/intent/compare",
        response_model=IntentComparison,
        **_api_docs(
            tag="意图解析",
            summary="对比规则基线与混合解析结果",
            purpose="用于调试和人工确认：在一个响应中并列纯规则基线、严格校验后的最终结果、实际变化字段和字段级接受/拒绝理由。",
            parameters="JSON 请求体只使用 `query`；兼容字段 `delivery_channel` 不参与意图对比。",
            returns="HTTP 200；`rules` 为确定性规则结果，`resolved` 为最终结果，`changed_fields` 仅列出真正发生变化的结构化字段。",
            side_effects="不抓取标讯、不写运行或订阅。与解析接口相同，满足配置条件时可能调用用户自己的模型服务。",
            errors="422：自然语言为空、过短或规则日期非法；模型不可用时仍以 HTTP 200 返回安全回退结果。",
            example='POST /api/v1/intent/compare\n{"query":"帮我查最近45天泉州储能系统项目"}',
            responses={422: "自然语言或规则字段不合法。"},
        ),
    )
    async def compare_intent(request: QueryRequest):
        try:
            return await service.compare_intent(request.query)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    @app.post(
        "/api/v1/runs",
        response_model=RunResult,
        **_api_docs(
            tag="情报任务",
            summary="立即执行一次情报任务",
            purpose="解析问题、访问已启用来源、清洗去重、生成证据摘要并持久化结果。即时任务即使保留 0 条，也会生成包含扫描漏斗、排除原因和覆盖边界的 Word 诊断报告。",
            parameters=(
                "JSON 请求体：`query` 为自然语言；网页应原样回传解析接口给出的 `intent_snapshot`，"
                "后端验证签名、时效和原问题后执行同一结构化意图，避免二次模型解析漂移。推荐用 `delivery_targets` 同时选择 1～10 个已配置目标。"
                "合法目标来自 `/api/v1/system/status` 的 `delivery_channels`。旧 `delivery_channel` 继续兼容；"
                "两者同时出现时，以 `delivery_targets` 为准，并把第一个目标回填到旧字段。"
            ),
            returns=(
                "HTTP 200；除运行、证据和报告字段外，`delivery_targets` 列出全部目标，"
                "`delivery_receipts` 逐目标返回 outbox_id 及 succeeded、retrying、dead_letter 或 skipped。"
                "单个渠道暂时失败时本轮通常返回 partial，失败目标进入持久重试，成功目标不会重发。"
            ),
            side_effects=(
                "【有副作用】访问来源并写运行、标讯和报告；报告记录、全部目标 Outbox 和目标公告集合"
                "会在首次外发前原子持久化，之后才并发发送。"
            ),
            errors=(
                "409：确认快照过期、被修改或与当前问题不一致；422：请求体字段非法；502：意图、来源、报告或持久入队在可恢复投递点之前失败。"
                "单个外部渠道超时不会让系统重新抓取，而会写入逐目标重试状态。"
            ),
            example=(
                'POST /api/v1/runs\n{"query":"最近1个月深圳充电桩招标信息",'
                '"delivery_targets":["local","email"]}'
            ),
            responses={422: "请求格式或字段校验失败。", 502: "检索、报告或持久入队失败。"},
        ),
    )
    async def run_query(request: QueryRequest):
        try:
            return await service.run_query(
                request.query,
                delivery_channel=request.delivery_channel,
                delivery_targets=request.delivery_targets,
                intent_snapshot=request.intent_snapshot,
            )
        except IntentSnapshotError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except Exception as exc:
            raise HTTPException(status_code=502, detail=str(exc)) from exc

    @app.get(
        "/api/v1/runs",
        **_api_docs(
            tag="情报任务",
            summary="列出最近运行记录",
            purpose="查看手动和自动任务的历史状态，便于审计失败、部分完成和报告生成情况。",
            parameters="查询参数 `limit`：返回条数，接口会限制在 1～100，默认 30。",
            returns="HTTP 200；按开始时间倒序返回运行数据库记录。",
            side_effects="无，只读 SQLite。",
            errors="参数无法转换为整数时返回 422。",
            example="GET /api/v1/runs?limit=20",
            responses={422: "limit 不是有效整数。"},
        ),
    )
    async def list_runs(limit: int = 30):
        return service.list_runs(min(max(limit, 1), 100))

    @app.get(
        "/api/v1/runs/{run_id}",
        **_api_docs(
            tag="情报任务",
            summary="读取单次运行详情",
            purpose="按运行 ID 获取状态、查询口径、计数、诊断和错误信息。",
            parameters="路径参数 `run_id`：任务返回的 32 位运行标识。",
            returns="HTTP 200；返回一条运行记录。",
            side_effects="无，只读 SQLite。",
            errors="404：运行 ID 不存在。",
            example="GET /api/v1/runs/2c4d8f0a1b2c3d4e5f60718293a4b5c6",
            responses={404: "未找到指定运行记录。"},
        ),
    )
    async def get_run(run_id: str):
        result = service.get_run(run_id)
        if result is None:
            raise HTTPException(status_code=404, detail="运行记录不存在")
        return result

    @app.get(
        "/api/v1/runs/{run_id}/evidence",
        response_model=list[TenderRecord],
        **_api_docs(
            tag="决策智能",
            summary="读取单次运行的固定证据快照",
            purpose="恢复该轮最终返回给用户的可信标讯，为重启后的适配判断和证据问答提供不可串轮的输入。",
            parameters="路径参数 `run_id` 为运行 ID；无请求体。",
            returns="HTTP 200；按当时排名返回该轮 TenderRecord 快照，后续全局抓取不会把新公告混入历史运行。",
            side_effects="无，只读 SQLite 的 run_items；不会调用模型或访问来源。",
            errors="404：运行不存在。运行存在但当轮无新增时返回空数组。",
            example="GET /api/v1/runs/2c4d8f0a1b2c3d4e5f60718293a4b5c6/evidence",
            responses={404: "运行记录不存在。"},
        ),
    )
    async def get_run_evidence(run_id: str):
        try:
            return service.get_run_evidence(run_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=_key_error_detail(exc)) from exc

    @app.post(
        "/api/v1/runs/{run_id}/assessments",
        response_model=OpportunityAssessmentSet,
        **_api_docs(
            tag="决策智能",
            summary="生成或刷新本轮企业适配判断",
            purpose="把固定运行证据、当前企业画像和有界反馈记忆合并为逐机会适配分、建议参与/观察/跳过、风险与下一步；模型只找语义关联和逐字证据，不直接给分。",
            parameters="路径 `run_id`；无请求体。模型开关、地址、超时和最多送入模型复核的条数来自网页配置中心；超出模型窗口的其余结果仍会获得本地判断。",
            returns="HTTP 200；返回模型/回退状态、画像版本、反馈数量、逐条证据编号，以及本地回填的标题、采购人、发布日期、地域、阶段、原文、本地适配分、逐字证据摘录、反馈调整和建议；每条本轮可信结果都有判断。",
            side_effects="可能调用用户配置的 OpenAI-compatible 模型并消耗额度；通过校验的结果按证据、画像、反馈和模型版本缓存，并写回该运行。不会访问标讯来源。",
            errors="404：运行不存在；模型未配置、超时、JSON 非法、未知证据或数字幻觉不会返回 502，而是返回确定性安全回退。",
            example="POST /api/v1/runs/2c4d8f0a1b2c3d4e5f60718293a4b5c6/assessments",
            responses={404: "运行记录不存在。"},
        ),
    )
    async def assess_run(run_id: str):
        try:
            return await service.assess_run(run_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=_key_error_detail(exc)) from exc

    @app.post(
        "/api/v1/runs/{run_id}/ask",
        response_model=EvidenceAnswer,
        **_api_docs(
            tag="决策智能",
            summary="只根据本轮固定证据追问",
            purpose="让用户针对某次已经结束的运行继续提问；模型只能选择本轮 E 编号和逐字原文，最终答案、标题、日期、阶段与链接均由本地组装。",
            parameters="路径 `run_id` 为已结束运行；JSON 仅含 question（2～1000 字，额外字段拒绝）。问题会在用户主动提交后发送给网页已配置模型，但不会保存明文聊天历史。",
            returns="HTTP 200；返回是否可回答、模型/回退/缓存状态、本地组装答案、逐条可点击引用、本轮总证据数、实际上下文数、是否截断和限制说明。",
            side_effects="可能调用 OpenAI-compatible 模型并消耗额度；只缓存通过 E 编号与逐字摘录校验的选择结果，不保存问题明文或模型原始响应，不重新访问标讯来源。",
            errors="404：运行不存在；409：运行仍在排队或执行；422：问题长度或额外字段非法。提示注入、未知 E 编号、证据损坏、模型超时或非法输出均返回结构化拒绝/回退，不返回 502。",
            example='POST /api/v1/runs/2c4d8f0a1b2c3d4e5f60718293a4b5c6/ask\n{"question":"E01 的采购人和公告阶段是什么？"}',
            responses={
                404: "运行记录不存在。",
                409: "运行尚未结束，固定证据未准备好。",
                422: "问题字段不合法。",
            },
        ),
    )
    async def ask_run(run_id: str, request: EvidenceQuestionRequest):
        try:
            return await service.ask_run(run_id, request.question)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=_key_error_detail(exc)) from exc
        except RunEvidenceNotReadyError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get(
        "/api/v1/company-profile",
        response_model=CompanyProfile,
        **_api_docs(
            tag="决策智能",
            summary="读取企业能力画像",
            purpose="让网页和 AI 决策引擎读取用户主动维护的产品、优势、目标地域、排除条件与决策偏好。",
            parameters="无请求体、无查询参数。",
            returns="HTTP 200；返回画像字段、内容版本和最后保存时间；首次使用返回可直接编辑的空画像。",
            side_effects="无。画像只从本机 SQLite 读取，不发送给招标来源。",
            errors="数据库不可用时返回 500；空画像不是错误。",
            example="GET /api/v1/company-profile",
        ),
    )
    async def get_company_profile():
        return service.get_company_profile()

    @app.put(
        "/api/v1/company-profile",
        response_model=CompanyProfile,
        **_api_docs(
            tag="决策智能",
            summary="保存企业能力画像",
            purpose="从网页图形化保存企业能够交付什么、擅长什么、优先哪里和明确不做什么，供后续适配评分使用。",
            parameters="请求头 `X-BidPilot-Config-Token` 必填；JSON 包含 company_name、offerings、strengths、target_regions、excluded_terms、preferred_buyers 和 decision_focus。未知字段拒绝。",
            returns="HTTP 200；返回规范化、去重后的画像、稳定版本和保存时间。",
            side_effects="【本地写入】覆盖默认企业画像并使后续适配缓存失效；不会触发检索、推送或把画像发给外站。",
            errors="403：短期编辑令牌无效；422：字段、枚举、条目数量或长度非法。",
            example='PUT /api/v1/company-profile\nX-BidPilot-Config-Token: <token>\n{"company_name":"示例科技","offerings":["AI服务器"],"strengths":["信创适配"],"target_regions":["广东"],"excluded_terms":[],"preferred_buyers":["高校"],"decision_focus":"balanced"}',
            responses={403: "编辑令牌缺失或过期。", 422: "画像字段未通过校验。"},
        ),
    )
    async def update_company_profile(
        profile: CompanyProfileUpdate,
        x_bidpilot_config_token: Annotated[
            str | None,
            Header(alias="X-BidPilot-Config-Token"),
        ] = None,
    ):
        require_config_token(x_bidpilot_config_token)
        return service.update_company_profile(profile)

    @app.get(
        "/api/v1/feedback",
        response_model=list[TenderFeedback],
        **_api_docs(
            tag="决策智能",
            summary="列出标讯反馈记忆",
            purpose="查看用户对真实标讯做出的相关、无关、观察和已联系判断，供网页解释个性化学习依据。",
            parameters="查询参数 `limit` 允许 1～5000，默认 500。",
            returns="HTTP 200；按最近修改时间返回反馈、可选原因和对应真实 TenderRecord。",
            side_effects="无；不会重新评分、调用模型或访问来源。",
            errors="limit 非整数返回 422。孤立或损坏反馈会被安全跳过。",
            example="GET /api/v1/feedback?limit=100",
        ),
    )
    async def list_feedback(limit: int = 500):
        return service.list_feedback(min(max(limit, 1), 5000))

    @app.put(
        "/api/v1/feedback/{canonical_id}/{version_hash}",
        response_model=TenderFeedback,
        **_api_docs(
            tag="决策智能",
            summary="新增或修改一条标讯反馈",
            purpose="让用户用明确判断纠正系统；同一公告版本重复提交会更新原反馈，不制造重复记忆。",
            parameters="路径 canonical_id 与 version_hash 必须对应本地真实 tender_items；请求头必须含短期编辑令牌；JSON verdict 为 relevant/irrelevant/watch/contacted，reason 可选。",
            returns="HTTP 200；返回保存后的反馈和本地证据记录。",
            side_effects="【本地写入】新增或覆盖一条反馈；后续个性化评分可使用它，但不能越过地域、日期、类型和排除词硬过滤。",
            errors="403：令牌无效；404：标讯不存在；422：枚举、原因长度或额外字段非法。",
            example='PUT /api/v1/feedback/<canonical_id>/<version_hash>\nX-BidPilot-Config-Token: <token>\n{"verdict":"relevant","reason":"与我们的信创服务器方案高度匹配"}',
            responses={403: "编辑令牌无效。", 404: "标讯证据不存在。", 422: "反馈字段非法。"},
        ),
    )
    async def set_feedback(
        canonical_id: str,
        version_hash: str,
        update: FeedbackUpdate,
        x_bidpilot_config_token: Annotated[
            str | None,
            Header(alias="X-BidPilot-Config-Token"),
        ] = None,
    ):
        require_config_token(x_bidpilot_config_token)
        try:
            return service.set_feedback(canonical_id, version_hash, update)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=_key_error_detail(exc)) from exc

    @app.delete(
        "/api/v1/feedback/{canonical_id}/{version_hash}",
        response_model=DeleteResultResponse,
        **_api_docs(
            tag="决策智能",
            summary="删除一条标讯反馈",
            purpose="撤销对某个公告版本的个性化判断，使后续评分不再使用该条记忆。",
            parameters="路径 canonical_id 与 version_hash；请求头必须含短期编辑令牌；无请求体。",
            returns='HTTP 200；返回 `{"deleted":true}`。',
            side_effects="【删除副作用】永久删除这一条本地反馈，不删除标讯、报告或机会。",
            errors="403：令牌无效；404：反馈不存在。",
            example="DELETE /api/v1/feedback/<canonical_id>/<version_hash>\nX-BidPilot-Config-Token: <token>",
            responses={403: "编辑令牌无效。", 404: "反馈不存在。"},
        ),
    )
    async def delete_feedback(
        canonical_id: str,
        version_hash: str,
        x_bidpilot_config_token: Annotated[
            str | None,
            Header(alias="X-BidPilot-Config-Token"),
        ] = None,
    ):
        require_config_token(x_bidpilot_config_token)
        try:
            service.delete_feedback(canonical_id, version_hash)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=_key_error_detail(exc)) from exc
        return {"deleted": True}

    @app.delete(
        "/api/v1/feedback",
        response_model=DeletedCountResponse,
        **_api_docs(
            tag="决策智能",
            summary="清空全部标讯反馈",
            purpose="在用户明确确认后重置个性化学习，不影响企业画像和历史标讯。",
            parameters="请求头必须含短期编辑令牌；无请求体。网页必须在调用前二次确认。",
            returns="HTTP 200；返回 deleted_count，表示实际删除条数。",
            side_effects="【批量删除】永久清空全部本地反馈；不删除运行、标讯、报告、订阅、机会或画像。",
            errors="403：编辑令牌无效。数据库错误返回 500。",
            example="DELETE /api/v1/feedback\nX-BidPilot-Config-Token: <token>",
            responses={403: "编辑令牌无效。"},
        ),
    )
    async def clear_feedback(
        x_bidpilot_config_token: Annotated[
            str | None,
            Header(alias="X-BidPilot-Config-Token"),
        ] = None,
    ):
        require_config_token(x_bidpilot_config_token)
        return {"deleted_count": service.clear_feedback()}

    @app.get(
        "/api/v1/reports",
        **_api_docs(
            tag="报告",
            summary="列出报告历史",
            purpose="展示已成功登记的 Word 报告及其运行、订阅、记录数和生成时间。",
            parameters="无请求体、无查询参数。",
            returns="HTTP 200；按生成时间倒序返回报告元数据，不返回文件正文。",
            side_effects="无，只读 SQLite。",
            errors="通常无业务错误；数据库不可用时返回 500。",
            example="GET /api/v1/reports",
        ),
    )
    async def list_reports():
        return service.list_reports()

    @app.get(
        "/api/v1/reports/{filename}",
        response_class=FileResponse,
        **_api_docs(
            tag="报告",
            summary="下载 Word 报告",
            purpose="下载报告目录中真实生成的 `.docx` 文件。服务端会剥离目录并校验扩展名，阻止路径穿越。",
            parameters="路径参数 `filename`：报告历史返回的文件名，只接受当前报告目录中的 `.docx`。",
            returns="HTTP 200；返回 Word 二进制流和下载文件名。",
            side_effects="无业务写入；会读取本机报告文件。",
            errors="404：文件不存在、扩展名不正确或路径不在报告目录内。",
            example="GET /api/v1/reports/深圳充电桩招标信息_202607181530.docx",
            responses={404: "报告不存在或文件名未通过安全校验。"},
        ),
    )
    async def download_report(filename: str):
        safe_name = Path(filename).name
        path = (settings.report_dir / safe_name).resolve()
        report_root = settings.report_dir.resolve()
        if report_root not in path.parents or not path.exists() or path.suffix.lower() != ".docx":
            raise HTTPException(status_code=404, detail="报告不存在")
        return FileResponse(
            path,
            filename=path.name,
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        )

    @app.get(
        "/api/v1/buyers",
        response_model=BuyerRadarResult,
        **_api_docs(
            tag="买方雷达",
            summary="查看本地买方活动雷达",
            purpose=(
                "只读取本机 SQLite 的 tender_items，把已经抓取并验证过的公告按采购单位聚合，"
                "展示公告数、估算项目数、最近活动、生命周期阶段、高频主题和可点击原文。"
                "不会联网补数、调用模型、生成联系人或推测未来采购。"
            ),
            parameters=(
                "查询参数 `search` 可按采购单位、主题或来源名称筛选，最长 100 字；"
                "`limit` 控制返回采购单位卡片数，范围 1～200、默认 100；"
                "`activity_limit` 控制每张卡的近期证据条数，范围 1～100、默认 5。"
            ),
            returns=(
                "HTTP 200；返回采购单位卡片、全局采购单位识别覆盖率、未识别公告数和损坏版本数。"
                "`notice_count` 按 canonical_id 去重，`project_count` 按既有 project_key 估算，"
                "证据 URL 全部从本地标讯快照回填。"
            ),
            side_effects="无。只读本地 tender_items，不访问招投标网站、不刷新授权、不调用 LLM，也不修改订阅。",
            errors=(
                "422：search、limit 或 activity_limit 不符合长度/范围约束；"
                "500：本地数据库不可读。单条历史快照损坏不会让接口失败，而会计入 invalid_version_count。"
            ),
            example="GET /api/v1/buyers?search=大学&limit=20&activity_limit=5",
            responses={422: "查询参数格式或范围非法。"},
        ),
    )
    async def list_buyer_radar(
        search: str = Query(
            default="",
            max_length=100,
            description="按采购单位名称、高频主题或来源名称进行本地筛选",
        ),
        limit: int = Query(
            default=100,
            ge=1,
            le=200,
            description="最多返回多少张采购单位卡片",
        ),
        activity_limit: int = Query(
            default=5,
            ge=1,
            le=100,
            description="每张采购单位卡片最多返回多少条近期公告证据",
        ),
    ):
        return service.list_buyer_radar(
            search=search,
            limit=limit,
            activity_limit=activity_limit,
        )

    @app.post(
        "/api/v1/buyers/{buyer_id}/subscriptions",
        response_model=Subscription,
        **_api_docs(
            tag="买方雷达",
            summary="从本地买方创建精准监控订阅",
            purpose=(
                "选择买方雷达中的真实采购单位，并把它作为 buyer_keywords 精确过滤条件创建长期任务。"
                "自然语言仍经过统一混合意图解析，后续运行仍使用统一检索计划、来源授权、调度租约、"
                "增量投递账本和失败重试；买方名称只来自本地记录，不由模型猜测。"
            ),
            parameters=(
                "路径参数 `buyer_id` 是 GET /api/v1/buyers 返回的 24 位本地稳定哈希。"
                "JSON 与普通订阅一致：`name`、含明确计划的 `query`、`delivery_targets`；"
                "解析预览返回的 `intent_snapshot` 应原样回传，用于锁定已确认的结构化意图。"
                "旧 `delivery_channel` 仍兼容。另含"
                "`delivery_policy`（always/on_change）和 `run_immediately`。"
            ),
            returns=(
                "HTTP 200；返回标准订阅对象。`spec.buyer_keywords` 明确列出锁定的采购单位，"
                "便于用户和审计人员确认后续结果不会混入其他买方。"
            ),
            side_effects=(
                "【有副作用】未回传快照时可能调用用户配置的意图模型；"
                "有效快照会直接复用已确认意图，再锁定本地采购单位，不会二次调用模型。"
                "随后写入 subscriptions。"
                "`run_immediately=true` 只把任务设为立即到期；持久 worker 领取后才会访问已接入来源、"
                "使用用户本人授权的会话、生成报告并按配置投递。不会生成联系人或采购预测。"
            ),
            errors=(
                "404：buyer_id 不对应当前本地买方；"
                "409：确认快照过期、签名不匹配、版本失效或与当前问题不一致，请重新解析确认；"
                "422：请求字段非法、自然语言没有可调度计划，"
                "投递通道尚未配置，或本地采购单位名称无法形成可靠来源查询。"
                "来源登录、网络和投递错误发生在实际运行中并写入运行审计。"
            ),
            example=(
                "POST /api/v1/buyers/0123456789abcdef01234567/subscriptions\n"
                '{"name":"安徽大学采购监控","query":"每天9点汇总最近30天服务器采购公告",'
                '"delivery_targets":["local","email"],"delivery_policy":"on_change",'
                '"run_immediately":false}'
            ),
            responses={
                404: "本地买方雷达中没有该采购单位。",
                409: "意图确认快照已失效或与当前问题不一致，请重新解析后再创建。",
                422: "计划、通道或请求字段校验失败。",
            },
        ),
    )
    async def create_buyer_subscription(
        buyer_id: Annotated[
            str,
            ApiPath(
                min_length=24,
                max_length=24,
                pattern=r"^[0-9a-f]{24}$",
                description="GET /api/v1/buyers 返回的采购单位本地稳定哈希",
            ),
        ],
        request: BuyerSubscriptionCreate,
    ):
        try:
            return await service.create_buyer_subscription(
                buyer_id,
                request.name,
                request.query,
                delivery_channel=request.delivery_channel,
                delivery_targets=request.delivery_targets,
                delivery_policy=request.delivery_policy,
                run_immediately=request.run_immediately,
                intent_snapshot=request.intent_snapshot,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=_key_error_detail(exc)) from exc
        except IntentSnapshotError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    @app.post(
        "/api/v1/subscriptions",
        **_api_docs(
            tag="长期订阅",
            summary="创建持久化订阅",
            purpose="把带有每天、每周、每月或一次性未来计划的自然语言保存为长期任务，并计算下一次执行时间。相同规则和同一组目标重复提交会复用原订阅。",
            parameters=(
                "JSON：`name`、`query`，以及解析预览返回的 `intent_snapshot`；网页回传快照后不会再次调用模型。`delivery_targets` 为 1～10 个已配置目标。"
                "旧 `delivery_channel` 等价于单元素列表；另有 `delivery_policy`（always/on_change）"
                "和 `run_immediately`。"
            ),
            returns="HTTP 200；返回订阅 ID、`delivery_targets`、兼容 `delivery_channel`、已确认解析规则、启用状态、下次时间，以及相互独立的最近检索状态和最近交付状态。",
            side_effects="【有副作用】写入订阅表；`run_immediately=true` 会把首轮设为立即到期，由持久 worker 领取。不会在请求线程内假装完成推送。",
            errors=(
                "409：确认快照过期、被修改或与当前问题不一致；"
                "422：规则不是可调度任务、通道未配置或字段非法。"
            ),
            example='POST /api/v1/subscriptions\n{"name":"深圳充电桩日报","query":"每天9点汇总最近1个月深圳充电桩信息","delivery_targets":["local","email"],"delivery_policy":"always","run_immediately":true}',
            responses={
                409: "确认快照已失效或与当前问题不一致，请重新解析。",
                422: "计划无法解析、通道未配置或请求字段非法。",
            },
        ),
    )
    async def create_subscription(request: SubscriptionCreate):
        try:
            return await service.create_subscription_hybrid(
                request.name,
                request.query,
                delivery_channel=request.delivery_channel,
                delivery_targets=request.delivery_targets,
                delivery_policy=request.delivery_policy,
                run_immediately=request.run_immediately,
                intent_snapshot=request.intent_snapshot,
            )
        except IntentSnapshotError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    @app.get(
        "/api/v1/subscriptions",
        **_api_docs(
            tag="长期订阅",
            summary="列出全部订阅",
            purpose="读取所有长期任务及其下次时间、租约、失败次数、最近检索状态和独立交付状态，供订阅中心区分来源覆盖受限与渠道待处理。",
            parameters="无请求体、无查询参数。",
            returns="HTTP 200；按创建时间倒序返回订阅列表。",
            side_effects="无，只读 SQLite。",
            errors="通常无业务错误；数据库不可用时返回 500。",
            example="GET /api/v1/subscriptions",
        ),
    )
    async def list_subscriptions():
        return service.list_subscriptions()

    @app.get(
        "/api/v1/subscriptions/{subscription_id}",
        **_api_docs(
            tag="长期订阅",
            summary="读取单个订阅",
            purpose="按订阅 ID 查看完整规则、状态、下次执行时间和是否正在被 worker 处理。",
            parameters="路径参数 `subscription_id`：创建订阅时返回的 ID。",
            returns="HTTP 200；返回订阅详情。",
            side_effects="无，只读 SQLite。",
            errors="404：订阅不存在。",
            example="GET /api/v1/subscriptions/f8b24edfbe64481dbcc7d4fdee85d94f",
            responses={404: "未找到指定订阅。"},
        ),
    )
    async def get_subscription(subscription_id: str):
        result = service.get_subscription(subscription_id)
        if result is None:
            raise HTTPException(status_code=404, detail="订阅不存在")
        return result

    @app.patch(
        "/api/v1/subscriptions/{subscription_id}",
        **_api_docs(
            tag="长期订阅",
            summary="编辑订阅规则或通道",
            purpose="局部修改名称、自然语言规则、多目标投递或无新增策略；修改规则后重新计算下一次时间，但保留仍在使用目标的防重复账本。",
            parameters=(
                "路径参数 `subscription_id`；JSON 仅提交要修改的 `name`、`query`、"
                "`delivery_targets`、兼容 `delivery_channel` 或 `delivery_policy`。修改 `query` 时，"
                "网页应先调用意图解析接口让用户确认，再把 `intent_snapshot` 与原问题一起提交。"
            ),
            returns="HTTP 200；返回更新后的订阅。",
            side_effects=(
                "【有副作用】更新持久化订阅和计划时间；有效意图快照直接复用用户已确认的结构化规则，"
                "不会二次调用模型。被移除目标尚未发送的 pending/retrying/dead_letter 任务会标为已取消，"
                "已经成功的审计记录保留。不会立即执行新检索。"
            ),
            errors=(
                "404：订阅不存在；409：订阅正在执行，或意图确认快照过期、被修改、"
                "与新问题不一致；422：新规则非法、新通道未配置或快照未与 query 同时提交。"
            ),
            example=(
                'PATCH /api/v1/subscriptions/{id}\n{"query":"每周一9点汇总深圳充电桩中标公告",'
                '"intent_snapshot":"解析接口返回的完整快照","delivery_policy":"on_change"}'
            ),
            responses={
                404: "订阅不存在。",
                409: "订阅当前有活跃租约，或意图确认快照已失效。",
                422: "规则或通道校验失败。",
            },
        ),
    )
    async def update_subscription(subscription_id: str, request: SubscriptionUpdate):
        try:
            return await service.update_subscription_hybrid(subscription_id, request)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except SubscriptionBusyError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except IntentSnapshotError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    @app.post(
        "/api/v1/subscriptions/{subscription_id}/run",
        response_model=RunResult,
        **_api_docs(
            tag="长期订阅",
            summary="立即运行一个订阅",
            purpose="用户手动触发已保存订阅，并通过租约与后台 worker 互斥，避免同一订阅并发执行。",
            parameters="路径参数 `subscription_id`；无请求体。",
            returns="HTTP 200；返回本轮 RunResult，包括新增数、报告和投递回执。",
            side_effects="【有副作用】真实抓取并先持久化报告与逐目标 Outbox，再按各目标独立公告集合发送；单目标成功与该目标防重复账本在同一事务提交。",
            errors="404：订阅不存在；409：正在执行；502：检索、报告或持久入队失败。单个渠道失败返回 partial 并由 worker 重试。",
            example="POST /api/v1/subscriptions/{id}/run",
            responses={404: "订阅不存在。", 409: "订阅正在执行。", 502: "本轮执行失败。"},
        ),
    )
    async def run_subscription(subscription_id: str):
        try:
            return await service.run_subscription(subscription_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except SubscriptionBusyError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except Exception as exc:
            raise HTTPException(status_code=502, detail=str(exc)) from exc

    @app.post(
        "/api/v1/subscriptions/{subscription_id}/pause",
        **_api_docs(
            tag="长期订阅",
            summary="暂停订阅",
            purpose="停止 worker 后续自动领取该订阅，同时保留规则、历史和防重复账本。",
            parameters="路径参数 `subscription_id`；无请求体。",
            returns="HTTP 200；返回 enabled=false 的订阅。",
            side_effects="【有副作用】持久化修改启用状态；不会中断已开始的抓取。",
            errors="404：订阅不存在；409：订阅正在执行，需等待本轮结束。",
            example="POST /api/v1/subscriptions/{id}/pause",
            responses={404: "订阅不存在。", 409: "订阅正在执行。"},
        ),
    )
    async def pause_subscription(subscription_id: str):
        try:
            return service.pause_subscription(subscription_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except SubscriptionBusyError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post(
        "/api/v1/subscriptions/{subscription_id}/resume",
        **_api_docs(
            tag="长期订阅",
            summary="恢复订阅",
            purpose="重新启用已暂停的订阅，并按原规则计算下一次时间；可选择立即进入待领取队列。",
            parameters="路径参数 `subscription_id`；JSON `run_immediately` 默认为 false。",
            returns="HTTP 200；返回恢复后的订阅与新 next_run_at。",
            side_effects="【有副作用】修改订阅启用状态和下一次时间；立即模式会让 worker 尽快执行。",
            errors="404：订阅不存在；409：已有活跃执行；422：原规则已无法形成有效计划。",
            example='POST /api/v1/subscriptions/{id}/resume\n{"run_immediately":false}',
            responses={404: "订阅不存在。", 409: "订阅正在执行。", 422: "计划无法恢复。"},
        ),
    )
    async def resume_subscription(subscription_id: str, request: ResumeRequest):
        try:
            return service.resume_subscription(
                subscription_id, run_immediately=request.run_immediately
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except SubscriptionBusyError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    @app.delete(
        "/api/v1/subscriptions/{subscription_id}",
        response_model=DeleteResultResponse,
        **_api_docs(
            tag="长期订阅",
            summary="删除订阅及增量账本",
            purpose="永久删除订阅；数据库外键会同时清除该订阅的目标级/兼容投递账本及尚未发送的 Outbox。运行、报告和既有尝试审计按现有保留策略处理。",
            parameters="路径参数 `subscription_id`；无请求体。网页端要求二次点击确认。",
            returns='HTTP 200；返回 `{"deleted":true}`。',
            side_effects="【不可逆副作用】删除订阅、防重复账本和待处理重试；删除后用同一规则重建可能再次推送历史版本。已经进入外部发送中的目标不能被可靠撤回，因此会先返回 409。",
            errors="404：订阅不存在；409：订阅检索或某个目标正在发送，拒绝删除。",
            example="DELETE /api/v1/subscriptions/{id}",
            responses={404: "订阅不存在。", 409: "订阅正在执行。"},
        ),
    )
    async def delete_subscription(subscription_id: str):
        try:
            service.delete_subscription(subscription_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except SubscriptionBusyError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        return {"deleted": True}

    @app.get(
        "/api/v1/subscriptions/{subscription_id}/runs",
        **_api_docs(
            tag="长期订阅",
            summary="查看订阅运行日志",
            purpose="读取指定订阅最近的自动/手动运行，定位失败、部分来源受限和新增数量。",
            parameters="路径参数 `subscription_id`；查询参数 `limit` 默认 20，整数小于 1 时按 1、大于 100 时按 100 读取。",
            returns="HTTP 200；按开始时间倒序返回运行记录。",
            side_effects="无，只读 SQLite。",
            errors="404：订阅不存在；422：limit 不是整数。",
            example="GET /api/v1/subscriptions/{id}/runs?limit=10",
            responses={404: "订阅不存在。", 422: "limit 参数非法。"},
        ),
    )
    async def list_subscription_runs(subscription_id: str, limit: int = 20):
        if service.get_subscription(subscription_id) is None:
            raise HTTPException(status_code=404, detail="订阅不存在")
        return service.list_subscription_runs(subscription_id, min(max(limit, 1), 100))

    @app.get(
        "/api/v1/subscriptions/{subscription_id}/deliveries",
        **_api_docs(
            tag="长期订阅",
            summary="查看订阅投递回执",
            purpose="审计每轮是否实际投递、是否因 on_change 跳过、通道消息和外部消息 ID。",
            parameters="路径参数 `subscription_id`；无请求体。",
            returns="HTTP 200；返回最近投递尝试列表，敏感凭据不会出现在回执中。",
            side_effects="无，只读 SQLite。",
            errors="404：订阅不存在。",
            example="GET /api/v1/subscriptions/{id}/deliveries",
            responses={404: "订阅不存在。"},
        ),
    )
    async def list_subscription_deliveries(subscription_id: str):
        if service.get_subscription(subscription_id) is None:
            raise HTTPException(status_code=404, detail="订阅不存在")
        return service.list_delivery_attempts(subscription_id)

    @app.get(
        "/api/v1/subscriptions/{subscription_id}/delivery-outbox",
        **_api_docs(
            tag="长期订阅",
            summary="查看订阅的逐目标持久投递队列",
            purpose=(
                "按一次运行、一个交付目标一行展示 pending、sending、retrying、"
                "succeeded、dead_letter 或 skipped 状态，用来判断哪个渠道已经完成、"
                "哪个渠道仍在后台重试。"
            ),
            parameters=(
                "路径参数 `subscription_id` 为订阅 ID；查询参数 `limit` 为返回行数，"
                "默认 100；整数小于 1 时按 1、大于 200 时按 200 读取。"
            ),
            returns=(
                "HTTP 200；每行包含 outbox ID、run ID、channel、status、attempt_count、"
                "max_attempts、next_attempt_at、item_count、脱敏错误、报告路径和外部消息 ID。"
            ),
            side_effects="无。只读 SQLite，不会触发推送，也不会修改下一次重试时间。",
            errors="404：订阅不存在；422：limit 不是整数。",
            example="GET /api/v1/subscriptions/{id}/delivery-outbox?limit=100",
            responses={404: "订阅不存在。", 422: "limit 参数非法。"},
        ),
    )
    async def list_subscription_delivery_outbox(subscription_id: str, limit: int = 100):
        if service.get_subscription(subscription_id) is None:
            raise HTTPException(status_code=404, detail="订阅不存在")
        return service.list_delivery_outbox(
            subscription_id=subscription_id,
            limit=limit,
        )

    @app.post(
        "/api/v1/delivery-outbox/{outbox_id}/retry",
        **_api_docs(
            tag="长期订阅",
            summary="手动重试一个死信交付目标",
            purpose=(
                "在用户修复渠道配置或网络后，只把指定 dead_letter 目标重新排队；"
                "不会重新抓取公告，也不会重新发送同一运行中已经成功的其他目标。"
            ),
            parameters="路径参数 `outbox_id` 来自逐目标投递队列；无请求体。",
            returns=(
                "HTTP 200；返回 status=retrying、attempt_count=0 和新的 next_attempt_at。"
                "持久 worker 随后领取；本接口本身不在 HTTP 请求线程内直接外发。"
            ),
            side_effects=(
                "【有副作用】清除该死信的上轮错误和租约并重新入队。"
                "已成功目标及其目标级防重复账本保持不变。"
            ),
            errors=(
                "404：outbox 不存在；409：任务不是死信或状态刚被其他操作改变；"
                "422：渠道仍未配置，或原报告文件已不存在。"
            ),
            example="POST /api/v1/delivery-outbox/{outbox_id}/retry",
            responses={
                404: "投递任务不存在。",
                409: "当前状态不能手动重试。",
                422: "必须先修复配置或重新生成报告。",
            },
        ),
    )
    async def retry_delivery_outbox(outbox_id: str):
        try:
            return service.retry_dead_letter(outbox_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=_key_error_detail(exc)) from exc
        except DeliveryOutboxStateError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    @app.post(
        "/api/v1/opportunities",
        response_model=Opportunity,
        **_api_docs(
            tag="机会工作台",
            summary="把真实标讯加入机会工作台",
            purpose="从 tender_items 中已抓取、已规范化的公告创建项目级机会；同一 project_key 重复加入返回原机会。",
            parameters="JSON：`canonical_id` 与 `version_hash` 必须来自 RunResult 中的真实记录。客户端不能上传自造标题或摘要。",
            returns="HTTP 200；返回机会、当前最新项目快照和人工跟进字段。",
            side_effects="【有副作用】写入机会表；若同项目已存在则只返回已有机会，不覆盖负责人、阶段和备注。",
            errors="404：标讯版本不存在，或提交的是伪造标识。",
            example='POST /api/v1/opportunities\n{"canonical_id":"cec-abc123","version_hash":"4b9f..."}',
            responses={404: "指定标讯不存在，不能创建无证据机会。"},
        ),
    )
    async def create_opportunity(request: OpportunityCreate):
        try:
            return service.create_opportunity(request)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=_key_error_detail(exc)) from exc

    @app.get(
        "/api/v1/opportunities",
        response_model=list[Opportunity],
        **_api_docs(
            tag="机会工作台",
            summary="筛选机会列表",
            purpose="按阶段和关键字读取项目级机会，用于看板、负责人检索和待办管理。",
            parameters="可选查询参数 `stage`：new/following/bidding/won/lost/archived；`search`：匹配项目、采购人、负责人、标签或备注。",
            returns="HTTP 200；返回匹配机会及每个项目的最新公告快照。",
            side_effects="无，只读 SQLite。",
            errors="422：stage 不是合法枚举值。",
            example="GET /api/v1/opportunities?stage=following&search=深圳",
            responses={422: "stage 参数非法。"},
        ),
    )
    async def list_opportunities(
        stage: OpportunityStage | None = None,
        search: str | None = None,
    ):
        return service.list_opportunities(stage=stage, search=search)

    @app.get(
        "/api/v1/opportunities/{opportunity_id}",
        response_model=Opportunity,
        **_api_docs(
            tag="机会工作台",
            summary="读取单个机会",
            purpose="按机会 ID 获取最新项目快照、阶段、负责人、下一步、标签和备注。",
            parameters="路径参数 `opportunity_id`。",
            returns="HTTP 200；返回 Opportunity。",
            side_effects="无，只读 SQLite。",
            errors="404：机会不存在。",
            example="GET /api/v1/opportunities/8f1c...",
            responses={404: "机会不存在。"},
        ),
    )
    async def get_opportunity(opportunity_id: str):
        result = service.get_opportunity(opportunity_id)
        if result is None:
            raise HTTPException(status_code=404, detail="机会不存在")
        return result

    @app.patch(
        "/api/v1/opportunities/{opportunity_id}",
        response_model=Opportunity,
        **_api_docs(
            tag="机会工作台",
            summary="更新机会跟进信息",
            purpose="局部更新阶段、负责人、下一步时间、备注、标签或已读状态；后续公告刷新不会覆盖这些人工字段。",
            parameters="路径参数 `opportunity_id`；JSON 可提交 `stage`、`owner`、`next_action_at`、`notes`、`tags`、`is_read`。",
            returns="HTTP 200；返回更新后的机会。",
            side_effects="【有副作用】写入人工跟进状态。不会修改原始标讯证据。",
            errors="404：机会不存在；422：阶段、日期或字段长度非法。",
            example='PATCH /api/v1/opportunities/{id}\n{"stage":"following","owner":"王同学","tags":["重点","充电桩"],"is_read":true}',
            responses={404: "机会不存在。", 422: "字段格式或枚举值非法。"},
        ),
    )
    async def update_opportunity(opportunity_id: str, request: OpportunityUpdate):
        try:
            return service.update_opportunity(opportunity_id, request)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=_key_error_detail(exc)) from exc

    @app.delete(
        "/api/v1/opportunities/{opportunity_id}",
        response_model=DeleteResultResponse,
        **_api_docs(
            tag="机会工作台",
            summary="从机会工作台删除卡片",
            purpose=(
                "移除用户不再跟进的机会卡片及其中的阶段、负责人、下一步、备注和标签。"
                "这只是工作台整理操作；同一真实标讯以后仍可重新加入。"
            ),
            parameters="路径参数 `opportunity_id`：机会卡片的本地 ID。无请求体；网页端应先进行二次确认。",
            returns='HTTP 200；删除成功返回 `{"deleted": true}`。',
            side_effects=(
                "【不可逆工作台操作】只删除 opportunities 中指定的一行。不会删除 tender_items 原始标讯、"
                "runs/run_items 运行证据、reports 报告、反馈、订阅或投递账本。已删卡片的人工跟进字段不会自动恢复。"
            ),
            errors="404：机会 ID 不存在或已经删除。数据库不可用时返回 500。",
            example="DELETE /api/v1/opportunities/8f1c...",
            responses={404: "机会不存在或已删除。"},
        ),
    )
    async def delete_opportunity(opportunity_id: str):
        try:
            service.delete_opportunity(opportunity_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=_key_error_detail(exc)) from exc
        return {"deleted": True}

    @app.get(
        "/api/v1/opportunities/{opportunity_id}/timeline",
        response_model=list[TenderRecord],
        **_api_docs(
            tag="机会工作台",
            summary="查看项目生命周期",
            purpose="读取同一 project_key 的采购意向、招标、更正、中标和合同事件，并保留每条原文证据。",
            parameters="路径参数 `opportunity_id`。",
            returns="HTTP 200；按发布时间升序返回 TenderRecord 列表。",
            side_effects="无，只读 SQLite。",
            errors="404：机会不存在。",
            example="GET /api/v1/opportunities/{id}/timeline",
            responses={404: "机会不存在。"},
        ),
    )
    async def opportunity_timeline(opportunity_id: str):
        try:
            return service.opportunity_timeline(opportunity_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=_key_error_detail(exc)) from exc

    @app.get(
        "/api/v1/system/status",
        response_model=SystemStatusResponse,
        **_api_docs(
            tag="系统",
            summary="读取运行时系统状态",
            purpose="为网页展示 worker 心跳、启用/到期/执行中订阅数量、时区和各投递通道是否已配置。",
            parameters="无请求体、无查询参数。",
            returns="HTTP 200；返回调度器与通道状态。只返回 configured 布尔值，不返回密钥、密码或 Webhook。",
            side_effects="无，只读数据库心跳和内存配置。",
            errors="通常无业务错误；数据库不可用时返回 500。",
            example="GET /api/v1/system/status",
        ),
    )
    async def system_status():
        return service.system_status()

    @app.post(
        "/api/v1/system/shutdown",
        **_api_docs(
            tag="系统",
            summary="优雅停止本机服务",
            purpose="供 `python -m bidpilot stop` 使用：先返回接收确认，再让当前 Uvicorn 服务停止接收新请求并执行 lifespan 清理。",
            parameters=(
                "请求必须在 `X-BidPilot-Control-Token` 请求头携带服务主机本地文件 "
                "`data/secrets/control.token` 中的随机令牌；CLI 从本机私有文件读取它。服务监听明确局域网"
                "地址时，请求可能经该接口地址回到本机，因此不额外依赖来源 IP。普通网页、LAN 管理员令牌"
                "和远程配置接口都拿不到此控制令牌。"
            ),
            returns='HTTP 202；返回 `{"accepted":true}`。随后服务通常在数秒内退出。',
            side_effects="【进程级副作用】停止当前 Web 进程及其内嵌 worker；不删除数据库、报告、订阅、机会或配置。",
            errors="403：本机控制令牌缺失或错误；409：当前进程不是由可控 `serve` 命令启动；服务已停止时无法连接。",
            example="POST /api/v1/system/shutdown\nX-BidPilot-Control-Token: <本机控制令牌>",
            responses={
                403: "本机控制令牌校验失败。",
                409: "当前启动方式不支持远程优雅停止。",
            },
        ),
        status_code=202,
    )
    async def shutdown_service(
        request: Request,
        x_bidpilot_control_token: Annotated[
            str | None,
            Header(alias="X-BidPilot-Control-Token"),
        ] = None,
    ):
        if not control_plane.verify(x_bidpilot_control_token):
            raise HTTPException(status_code=403, detail="只允许持有本机控制令牌的 CLI 停止服务")
        callback = getattr(request.app.state, "shutdown_callback", None)
        if callback is None:
            raise HTTPException(
                status_code=409, detail="当前服务不是由可控 serve 命令启动，请在终端按 Ctrl+C"
            )
        asyncio.get_running_loop().call_later(0.2, callback)
        return {"accepted": True, "message": "已接收停止请求，正在完成清理"}

    @app.get(
        "/api/v1/sources/status",
        **_api_docs(
            tag="系统",
            summary="读取数据源状态",
            purpose="查看每个来源的官方/行业属性、公开或授权模式、最近状态、抓取/保留数量和诊断信息。",
            parameters="无请求体、无查询参数。",
            returns="HTTP 200；返回来源状态列表；未授权来源明确标记 auth_required，不伪装为成功。",
            side_effects="无。不会为了查看状态而临时访问来源网站。",
            errors="通常无业务错误；数据库不可用时返回 500。",
            example="GET /api/v1/sources/status",
        ),
    )
    async def source_status():
        return service.source_status()

    @app.get(
        "/api/v1/sources/health",
        **_api_docs(
            tag="来源运维",
            summary="读取来源健康历史与趋势",
            purpose="按来源聚合最近真实运行样本，区分正常、降级、持续失败、等待授权、按地域跳过和无数据，并计算耗时与产出趋势。",
            parameters="查询参数 window 表示每个来源最多统计多少次运行，允许 5–100，默认 20；超出范围会安全收敛到边界。",
            returns="HTTP 200；返回总体健康摘要和逐来源状态计数、健康率、完成率、平均/P95 耗时、候选保留率、趋势及逐次脱敏诊断。",
            side_effects="无。只读取 SQLite 已有 source_runs，不会访问外站、刷新授权、执行检索或修改配置。",
            errors="数据库不可读时返回 500；没有历史不是错误，对应来源返回 no_data 和零样本说明。",
            example="GET /api/v1/sources/health?window=20",
        ),
    )
    async def source_health(window: int = 20):
        return service.source_health(window)

    @app.get(
        "/api/v1/sources/authorizations",
        response_model=list[SourceAuthView],
        **_api_docs(
            tag="来源授权",
            summary="读取全部来源的脱敏授权状态",
            purpose="来源中心用它区分无需授权、可管理授权、正在登录、已授权、已过期以及仅能打开原站工作台的来源。",
            parameters="无请求体、无查询参数。",
            returns="HTTP 200；逐来源返回状态、官方登录页、授权真实作用范围、时间和测试结论；不返回 Cookie 名称或值。",
            side_effects="无。不会打开浏览器、访问外站或刷新会话。",
            errors="通常无业务错误；数据库不可用时返回 500。",
            example="GET /api/v1/sources/authorizations",
        ),
    )
    async def list_source_authorizations():
        return service.source_auth.list_status()

    @app.post(
        "/api/v1/sources/{source_id}/auth/start",
        response_model=SourceAuthSessionView,
        **_api_docs(
            tag="来源授权",
            summary="开始可见浏览器授权",
            purpose="在运行 BidPilot 服务的电脑上打开独立可见 Chromium，让用户本人登录、扫码、输入验证码或按原站要求使用 CA。局域网设备可以发起和管理流程，但浏览器窗口不会出现在手机上。",
            parameters="路径 source_id 当前支持 cecbid；请求头必须含 X-BidPilot-Config-Token。局域网请求还遵循已生效的管理员令牌或可信网段策略；无请求体。",
            returns="HTTP 200；返回一次性会话 ID、15 分钟截止时间和操作提示。",
            side_effects="【服务主机副作用】启动一个可见浏览器进程并打开官方登录页；不会自动输入账号、密码、验证码或点击提交。",
            errors="403：短期编辑令牌无效，或局域网访问策略未通过；409：来源不支持安全复用授权、浏览器组件缺失或 Chromium 无法启动。",
            example="POST /api/v1/sources/cecbid/auth/start\nX-BidPilot-Config-Token: <token>",
            responses={
                403: "编辑令牌或局域网访问策略未通过。",
                409: "来源不支持或浏览器组件不可用。",
            },
        ),
    )
    async def start_source_authorization(
        source_id: str,
        request: Request,
        x_bidpilot_config_token: Annotated[
            str | None,
            Header(alias="X-BidPilot-Config-Token"),
        ] = None,
    ):
        require_management_config_token(x_bidpilot_config_token)
        try:
            return await service.source_auth.start(source_id)
        except SourceAuthError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get(
        "/api/v1/sources/auth/sessions/{session_id}",
        response_model=SourceAuthSessionView,
        **_api_docs(
            tag="来源授权",
            summary="查看一次授权窗口状态",
            purpose="确认可见浏览器授权窗口是否仍在 15 分钟有效期内，以及是否已经完成、失败或过期。",
            parameters="路径 session_id 来自开始授权接口；不需要请求体。",
            returns="HTTP 200；返回脱敏状态和下一步中文提示。",
            side_effects="只会清理已经超时的本机浏览器会话；不会读取或保存 Cookie。",
            errors="404：会话不存在或服务重启后已失效。",
            example="GET /api/v1/sources/auth/sessions/<session_id>",
            responses={404: "会话不存在。"},
        ),
    )
    async def get_source_authorization_session(session_id: str):
        try:
            return await service.source_auth.session(session_id)
        except SourceAuthError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    @app.post(
        "/api/v1/sources/auth/sessions/{session_id}/complete",
        response_model=SourceAuthSessionView,
        **_api_docs(
            tag="来源授权",
            summary="完成并加密保存授权",
            purpose="用户确认已完成登录后，读取临时浏览器中属于允许域名的 Cookie，加密写入 SQLite 并关闭授权浏览器。",
            parameters="路径 session_id；请求头必须含短期编辑令牌；无请求体。",
            returns="HTTP 200；返回 completed 或 failed 及脱敏原因。不会返回 Cookie 名称和值。",
            side_effects="【敏感写入】仅保存允许域名的会话 Cookie，使用本机 Fernet 密钥加密；不保存账号、密码、验证码或 CA。",
            errors="403：编辑令牌无效或局域网访问策略未通过；404：会话不存在；409：未检测到允许域名会话。",
            example="POST /api/v1/sources/auth/sessions/<session_id>/complete\nX-BidPilot-Config-Token: <token>",
            responses={403: "编辑令牌或局域网访问策略未通过。", 404: "会话不存在。"},
        ),
    )
    async def complete_source_authorization(
        session_id: str,
        request: Request,
        x_bidpilot_config_token: Annotated[
            str | None,
            Header(alias="X-BidPilot-Config-Token"),
        ] = None,
    ):
        require_management_config_token(x_bidpilot_config_token)
        try:
            result = await service.source_auth.complete(session_id)
        except SourceAuthError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        if result.status == "failed":
            raise HTTPException(status_code=409, detail=result.message)
        return result

    @app.post(
        "/api/v1/sources/{source_id}/auth/test",
        response_model=SourceAuthTestResult,
        **_api_docs(
            tag="来源授权",
            summary="真实测试来源授权",
            purpose="携带已加密保存的会话执行一次有界真实搜索，确认来源不再要求登录并实际读取到会员可见内容。",
            parameters="路径 source_id；请求头必须含短期编辑令牌；无请求体。",
            returns="HTTP 200；返回 passed/failed、耗时和脱敏诊断，不返回请求 Cookie。",
            side_effects="【外部调用】会访问来源的服务器关键词检索；遵守全局限速和重试上限，不下载付费文件。",
            errors="403：编辑令牌无效或局域网访问策略未通过；409：尚未授权或来源不支持；502：授权测试失败。",
            example="POST /api/v1/sources/cecbid/auth/test\nX-BidPilot-Config-Token: <token>",
            responses={
                403: "编辑令牌或局域网访问策略未通过。",
                409: "尚未授权。",
                502: "真实测试未证明授权有效。",
            },
        ),
    )
    async def test_source_authorization(
        source_id: str,
        request: Request,
        x_bidpilot_config_token: Annotated[
            str | None,
            Header(alias="X-BidPilot-Config-Token"),
        ] = None,
    ):
        require_management_config_token(x_bidpilot_config_token)
        try:
            result = await service.source_auth.test(source_id)
        except SourceAuthError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        if not result.success:
            raise HTTPException(status_code=502, detail=result.message)
        return result

    @app.delete(
        "/api/v1/sources/{source_id}/auth",
        response_model=SourceAuthView,
        **_api_docs(
            tag="来源授权",
            summary="清除来源授权",
            purpose="关闭该来源仍在进行的授权窗口，删除 SQLite 中的加密 Cookie，并立即停止后续会员增强检索。",
            parameters="路径 source_id；请求头必须含短期编辑令牌；无请求体。",
            returns="HTTP 200；返回 not_authorized 脱敏状态。",
            side_effects="【删除副作用】永久删除本机保存的该来源加密会话；不会注销原网站账号，也不会修改账号密码。",
            errors="403：编辑令牌无效或局域网访问策略未通过；409：该来源没有受管授权。",
            example="DELETE /api/v1/sources/cecbid/auth\nX-BidPilot-Config-Token: <token>",
            responses={403: "编辑令牌或局域网访问策略未通过。", 409: "来源没有受管授权。"},
        ),
    )
    async def clear_source_authorization(
        source_id: str,
        request: Request,
        x_bidpilot_config_token: Annotated[
            str | None,
            Header(alias="X-BidPilot-Config-Token"),
        ] = None,
    ):
        require_management_config_token(x_bidpilot_config_token)
        try:
            return await service.source_auth.clear(source_id)
        except SourceAuthError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get(
        "/api/v1/config",
        response_model=RuntimeConfigView,
        **_api_docs(
            tag="配置中心",
            summary="读取脱敏后的运行时配置",
            purpose="为网页配置中心读取 AI、检索、worker、网络访问、报告发布，以及飞书、SMTP、钉钉、企业微信、通用 Webhook、Telegram 和 Slack 的非敏感字段、来源、版本与就绪状态。",
            parameters="无请求体、无查询参数。",
            returns="HTTP 200；返回 revision、字段来源和当前/重启后网络状态；敏感字段仅返回 `{configured:true/false}`，永不返回管理员令牌、API Key、密码、Cookie、Webhook 完整地址、签名密钥或 Bearer Token。",
            side_effects="无，只读 SQLite 与当前内存设置。",
            errors="通常无业务错误；数据库不可用时返回 500。",
            example="GET /api/v1/config",
        ),
    )
    async def get_runtime_config():
        return service.runtime_config.snapshot()

    @app.post(
        "/api/v1/config/edit-token",
        response_model=ConfigEditTokenResponse,
        **_api_docs(
            tag="配置中心",
            summary="签发短期配置编辑令牌",
            purpose="同源网页在保存或测试前获取一次性会话令牌，用自定义请求头抵御跨站表单直接修改本机配置。",
            parameters="无请求体。后续写请求把返回值放入 `X-BidPilot-Config-Token` 请求头。",
            returns="HTTP 200；返回随机编辑令牌和有效秒数。响应带 `Cache-Control: no-store`。",
            side_effects="在当前进程内登记一个短期令牌；不写数据库，进程重启后自动失效。",
            errors="令牌池异常时返回 500；正常情况下无业务错误。",
            example="POST /api/v1/config/edit-token\n后续请求头：X-BidPilot-Config-Token: <返回的短期令牌>",
        ),
    )
    async def issue_config_edit_token(response: Response):
        token, expires_in = config_tokens.issue()
        response.headers["Cache-Control"] = "no-store"
        return ConfigEditTokenResponse(edit_token=token, expires_in=expires_in)

    @app.put(
        "/api/v1/config",
        response_model=RuntimeConfigView,
        **_api_docs(
            tag="配置中心",
            summary="保存白名单运行时配置",
            purpose="在网页中按字段保存 AI、检索、worker、网络和推送通道设置。仅接受 schema 明列字段；普通字段立即生效，网络字段在重启后一次性生效，避免保存瞬间改变当前连接权限。",
            parameters="请求头必须含短期编辑令牌。JSON 必须携带读取时得到的 `revision`，可局部提交任意白名单字段；`network_access_mode` 为 local/lan，`lan_access_policy` 为 admin_token/trusted_lan，`lan_trusted_networks` 可用 auto。敏感字段留空表示保持原值，清除放入 `clear_secrets`，普通字段恢复环境变量/默认值放入 `reset_fields`。",
            returns="HTTP 200；返回脱敏后的最新 RuntimeConfigView、递增 revision，以及网络配置当前生效值和重启后值。",
            side_effects="【有副作用】原子写入 runtime_config 表并更新共享 Settings。未知字段被拒绝；网络监听和 LAN 权限在重启前保持不变；响应和日志不回显敏感原文。",
            errors="403：编辑令牌或局域网策略未通过；409：revision 已过期；422：未知字段、网段、令牌强度、URL、端口、超时或枚举值非法。",
            example='PUT /api/v1/config\nX-BidPilot-Config-Token: <token>\n{"revision":3,"network_access_mode":"lan","lan_access_policy":"trusted_lan","lan_trusted_networks":"auto"}',
            responses={
                403: "编辑令牌或局域网访问策略未通过。",
                409: "配置版本冲突。",
                422: "字段不在白名单或值未通过校验。",
            },
        ),
    )
    async def update_runtime_config(
        payload: RuntimeConfigUpdate,
        x_bidpilot_config_token: Annotated[
            str | None,
            Header(alias="X-BidPilot-Config-Token"),
        ] = None,
    ):
        require_config_token(x_bidpilot_config_token)
        try:
            return service.runtime_config.update(payload)
        except RuntimeConfigConflict as exc:
            raise HTTPException(
                status_code=409,
                detail=(
                    f"配置版本冲突：服务器当前 revision={exc.current_revision}，"
                    "请重新读取配置并确认未保存草稿"
                ),
            ) from exc
        except RuntimeConfigError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    @app.post(
        "/api/v1/config/model/test",
        response_model=ConnectionTestResult,
        **_api_docs(
            tag="配置中心",
            summary="测试 OpenAI-compatible 模型",
            purpose="使用当前已保存地址、模型和可选 API Key 调用 `/chat/completions`，验证真实连通性与兼容响应格式。",
            parameters="请求头必须含短期编辑令牌；无请求体。请先保存 `llm_base_url` 与 `llm_model`。",
            returns="HTTP 200；返回成功标志、目标、脱敏消息、延迟和最多 120 字的固定测试回复。",
            side_effects="【外部调用】向用户配置的模型服务发送固定测试句，可能消耗极少量模型额度；不发送招标数据，也不回显 API Key。",
            errors="403：令牌无效；422：模型地址/名称未配置；502：超时、HTTP 错误或响应不兼容。",
            example="POST /api/v1/config/model/test\nX-BidPilot-Config-Token: <token>",
            responses={
                403: "编辑令牌无效或过期。",
                422: "模型配置不完整。",
                502: "模型连接或兼容性测试失败。",
            },
        ),
    )
    async def test_model_connection(
        x_bidpilot_config_token: Annotated[
            str | None,
            Header(alias="X-BidPilot-Config-Token"),
        ] = None,
    ):
        require_config_token(x_bidpilot_config_token)
        if not service.runtime_config.snapshot().ai.ready:
            raise HTTPException(status_code=422, detail="请先保存模型 API 地址和模型名称")
        try:
            return await service.runtime_config.test_model()
        except RuntimeConfigError as exc:
            raise HTTPException(status_code=502, detail=str(exc)) from exc

    @app.post(
        "/api/v1/config/channels/{channel}/test",
        response_model=ConnectionTestResult,
        **_api_docs(
            tag="配置中心",
            summary="真实测试一个推送通道",
            purpose="通过指定通道发送一条明确标记为“配置中心连通性测试”的无新增回执，验证凭据、网络和平台配置。",
            parameters="路径 `channel`：feishu_webhook、feishu_app、email、dingtalk_webhook、wecom_webhook、generic_webhook、telegram_bot 或 slack_webhook；请求头必须含短期编辑令牌。",
            returns="HTTP 200；返回实际通道、平台回执、延迟和成功状态。",
            side_effects="【真实外发副作用】会向已配置群聊、用户、邮箱或 Webhook 接收方发送一条测试消息；网页调用前会二次确认。",
            errors="403：令牌无效；422：通道不支持或未配置；502：网络、认证、平台安全设置或响应失败。",
            example="POST /api/v1/config/channels/dingtalk_webhook/test\nX-BidPilot-Config-Token: <token>",
            responses={
                403: "编辑令牌无效或过期。",
                422: "通道不存在或配置不完整。",
                502: "真实测试消息发送失败。",
            },
        ),
    )
    async def test_delivery_channel(
        channel: str,
        x_bidpilot_config_token: Annotated[
            str | None,
            Header(alias="X-BidPilot-Config-Token"),
        ] = None,
    ):
        require_config_token(x_bidpilot_config_token)
        status = next(
            (item for item in service.delivery.channel_status() if item["id"] == channel),
            None,
        )
        if status is None or channel == "local":
            raise HTTPException(status_code=422, detail="不支持测试该投递通道")
        if not status["configured"]:
            raise HTTPException(status_code=422, detail="该投递通道尚未完成配置")
        started = perf_counter()
        try:
            receipt = await service.delivery.deliver(
                None,
                channel,
                new_count=0,
                subscription_name="配置中心连通性测试",
            )
        except DeliveryError as exc:
            raise HTTPException(status_code=502, detail=f"通道测试失败：{exc}") from exc
        except Exception as exc:
            raise HTTPException(
                status_code=502,
                detail="通道测试失败，请检查地址、凭据、网络和平台安全设置",
            ) from exc
        return ConnectionTestResult(
            success=receipt.success,
            target=receipt.channel,
            message=receipt.message,
            latency_ms=round((perf_counter() - started) * 1000),
        )

    return app


app = create_app()
